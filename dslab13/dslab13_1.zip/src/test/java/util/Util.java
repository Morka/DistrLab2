package util;

public class Util {
	
	public static final int WAIT_FOR_COMPONENT_STARTUP = 2000;

}
