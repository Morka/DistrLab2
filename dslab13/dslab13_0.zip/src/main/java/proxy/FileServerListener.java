package proxy;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class FileServerListener implements Runnable
{
	private DatagramSocket socket;
	private int timeout;
	private int checkPeriod;
	private AtomicBoolean stop;
	private HashMap<Integer, Long> lastOnline;
	/*
	 * Internet adress is the key, values (in that order) are TCP port, online status, usage
	 */
	private ConcurrentHashMap<InetAddress, ArrayList<String>> servers;

	private HashSet<String> files;

	public FileServerListener(DatagramSocket socket, int timeout, int checkPeriod, ConcurrentHashMap<InetAddress, ArrayList<String>> servers, AtomicBoolean stop, HashSet<String> files)
	{
		this.socket = socket;
		this.timeout = timeout;
		this.checkPeriod = checkPeriod;
		this.servers = servers;
		this.stop = stop;
		this.files = files;
		lastOnline = new HashMap<Integer, Long>();
	}

	@Override
	public void run()
	{
		byte[] buffer;
		while(!stop.get())
		{
			buffer = new byte[4];
			DatagramPacket p = new DatagramPacket(buffer, buffer.length);
			Long current = System.currentTimeMillis();
			try
			{
				socket.receive(p);
				InetAddress address = p.getAddress();
				ByteBuffer wrapped = ByteBuffer.wrap(p.getData());
				int port = wrapped.getInt();
				lastOnline.put(port, current);
				synchronized(servers)
				{
					if(!servers.containsValue(port))
					{
						ArrayList<String> values = new ArrayList<String>();
						values.add(String.valueOf(port));
						values.add("online");
						values.add("0");
						servers.put(address, values);
					}
				}
				if(current - lastOnline.get(port) > timeout)
				{
					synchronized(servers)
					{
						ArrayList<String> values = new ArrayList<String>();
						values.set(1, "offline");
					}
				}

			}
			catch (SocketException se)
			{
				return;
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
